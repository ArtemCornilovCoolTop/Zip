
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GoogleGenAI, Modality, Type, LiveServerMessage } from '@google/genai';
import { AppTheme, Command, Message, ChatSession } from './types';
import { INITIAL_COMMANDS, SYSTEM_INSTRUCTION } from './constants';
import { decode, encode, decodeAudioData } from './services/audio-helpers';

// Voice configuration
const VOICE_OPTIONS = {
  male: [
    { id: 'Charon', name: 'Харон', desc: 'Глубокий и серьезный' },
    { id: 'Fenrir', name: 'Фенрир', desc: 'Сильный и уверенный' },
    { id: 'Puck', name: 'Пак', desc: 'Легкий и дружелюбный' }
  ],
  female: [
    { id: 'Aoede', name: 'Аэда', desc: 'Спокойный и мягкий' },
    { id: 'Kore', name: 'Кора', desc: 'Профессиональный' },
    { id: 'Zephyr', name: 'Зефир', desc: 'Энергичный и яркий' }
  ]
};

const StatusPill: React.FC<{ active: boolean; label: string }> = ({ active, label }) => (
  <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium transition-colors ${active ? 'bg-blue-500/20 text-blue-500' : 'bg-gray-500/20 text-gray-500'}`}>
    <div className={`w-2 h-2 rounded-full ${active ? 'bg-blue-500 animate-pulse' : 'bg-gray-500'}`} />
    {label}
  </div>
);

const App: React.FC = () => {
  const [theme, setTheme] = useState<AppTheme>(AppTheme.DARK);
  const [isRecording, setIsRecording] = useState(false);
  const [commands, setCommands] = useState<Command[]>(INITIAL_COMMANDS);
  
  // Session Management
  const [sessions, setSessions] = useState<ChatSession[]>([
    { id: 'default', title: 'Новый чат', messages: [], createdAt: Date.now() }
  ]);
  const [activeSessionId, setActiveSessionId] = useState<string>('default');
  
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [operationStatus, setOperationStatus] = useState<string | null>(null);
  
  // Voice selection state
  const [voiceGender, setVoiceGender] = useState<'male' | 'female'>('female');
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>('Kore');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const currentInputTranscriptionRef = useRef('');
  const currentOutputTranscriptionRef = useRef('');
  const currentMessageIdRef = useRef<{user?: string, assistant?: string}>({});

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];
  const messages = activeSession.messages;

  useEffect(() => {
    navigator.mediaDevices.enumerateDevices().then(devices => {
      const mics = devices.filter(d => d.kind === 'audioinput');
      setAudioDevices(mics);
      if (mics.length > 0) setSelectedDeviceId(mics[0].deviceId);
    });
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const createNewChat = () => {
    const newSession: ChatSession = {
      id: Math.random().toString(36).substring(7),
      title: 'Новый чат',
      messages: [],
      createdAt: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  const clearCurrentChat = useCallback(() => {
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId ? { ...s, messages: [], title: 'Новый чат' } : s
    ));
  }, [activeSessionId]);

  const updateStreamingMessage = useCallback((text: string, sender: 'user' | 'assistant') => {
    setSessions(prev => prev.map(session => {
      if (session.id !== activeSessionId) return session;

      const id = currentMessageIdRef.current[sender];
      const existingIdx = session.messages.findIndex(m => m.id === id);

      let updatedMessages = [...session.messages];
      if (existingIdx !== -1) {
        updatedMessages[existingIdx] = { ...updatedMessages[existingIdx], text };
      } else {
        const newId = Math.random().toString(36).substring(7);
        currentMessageIdRef.current[sender] = newId;
        updatedMessages.push({
          id: newId,
          text,
          sender,
          timestamp: Date.now()
        });
      }

      // Automatically title the chat based on first user message
      let newTitle = session.title;
      if (sender === 'user' && session.messages.length === 0 && text.length > 5) {
        newTitle = text.slice(0, 25) + (text.length > 25 ? '...' : '');
      }

      return { ...session, messages: updatedMessages, title: newTitle };
    }));
  }, [activeSessionId]);

  const handleCommandExecution = useCallback((name: string, args: any) => {
    setIsProcessing(true);
    let statusMsg = "Обработка...";
    if (name === 'generate_command') statusMsg = `Генерация: ${args.name || 'Script'}`;
    if (name === 'manage_filesystem') statusMsg = `Файлы: ${args.operation}`;
    if (name === 'execute_command') statusMsg = `Запуск: ${args.name}`;
    if (name === 'clear_chat') {
        clearCurrentChat();
        statusMsg = "Очистка чата...";
    }
    
    setOperationStatus(statusMsg);

    const delay = name === 'generate_command' ? 3000 : 1000;

    setTimeout(() => {
      if (name === 'change_theme') {
        setTheme(args.mode === 'light' ? AppTheme.LIGHT : AppTheme.DARK);
      } else if (name === 'generate_command' || name === 'manage_filesystem') {
        const newCmd: Command = {
          id: Math.random().toString(36).substring(7),
          name: args.name || 'AI Automation',
          description: args.description || args.operation || 'Dynamic logic',
          type: 'custom',
          code: args.code || args.powershell
        };
        setCommands(prev => [newCmd, ...prev].slice(0, 15));
      }
      setIsProcessing(false);
      setOperationStatus(null);
    }, delay);

    return "ok";
  }, [clearCurrentChat]);

  const stopSession = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    setIsRecording(false);
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    currentInputTranscriptionRef.current = '';
    currentOutputTranscriptionRef.current = '';
    currentMessageIdRef.current = {};
    setOperationStatus(null);
  }, []);

  const startSession = async () => {
    if (isRecording) {
      stopSession();
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = inCtx;
      outputAudioContextRef.current = outCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { deviceId: selectedDeviceId ? { exact: selectedDeviceId } : undefined } 
      });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoiceId } },
          },
          systemInstruction: SYSTEM_INSTRUCTION,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          tools: [
            {
              functionDeclarations: [
                {
                    name: 'clear_chat',
                    description: 'Clears the current chat history',
                    parameters: { type: Type.OBJECT, properties: {} }
                },
                {
                  name: 'manage_filesystem',
                  description: 'File system tasks (copy, move, delete, zip)',
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      operation: { type: Type.STRING },
                      source: { type: Type.STRING },
                      destination: { type: Type.STRING },
                      powershell: { type: Type.STRING }
                    },
                    required: ['operation']
                  }
                },
                {
                  name: 'execute_command',
                  description: 'Executes a Windows system command',
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      args: { type: Type.OBJECT }
                    },
                    required: ['name', 'args']
                  }
                },
                {
                  name: 'generate_command',
                  description: 'Creates a custom program or script',
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      description: { type: Type.STRING },
                      code: { type: Type.STRING }
                    },
                    required: ['name', 'code']
                  }
                }
              ]
            }
          ]
        },
        callbacks: {
          onopen: () => {
            setIsRecording(true);
            const source = inCtx.createMediaStreamSource(stream);
            const scriptProcessor = inCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.inputTranscription) {
              currentInputTranscriptionRef.current += msg.serverContent.inputTranscription.text;
              updateStreamingMessage(currentInputTranscriptionRef.current, 'user');
            }
            if (msg.serverContent?.outputTranscription) {
              currentOutputTranscriptionRef.current += msg.serverContent.outputTranscription.text;
              updateStreamingMessage(currentOutputTranscriptionRef.current, 'assistant');
            }

            if (msg.serverContent?.turnComplete) {
              currentInputTranscriptionRef.current = '';
              currentOutputTranscriptionRef.current = '';
              currentMessageIdRef.current = {};
            }

            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && outCtx) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outCtx, 24000, 1);
              const source = outCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outCtx.destination);
              source.onended = () => sourcesRef.current.delete(source);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }

            if (msg.toolCall) {
              for (const fc of msg.toolCall.functionCalls) {
                const result = handleCommandExecution(fc.name, fc.args);
                sessionPromise.then(session => session.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result } }
                }));
              }
            }
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: () => stopSession(),
          onclose: () => stopSession(),
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Session failed:", err);
      stopSession();
    }
  };

  return (
    <div className={`h-screen transition-colors duration-500 flex flex-col overflow-hidden ${theme === AppTheme.DARK ? 'dark bg-zinc-950 text-zinc-100' : 'bg-zinc-50 text-zinc-900'}`}>
      {/* Top Bar */}
      <header className="mica z-50 flex items-center justify-between px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30 relative">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <div className="absolute -top-1 -right-1">
              <svg className="w-4 h-4 text-yellow-400 fill-yellow-400 animate-pulse" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            </div>
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">AI Assistant</h1>
            <p className="text-xs opacity-60">Windows AI Beta</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <StatusPill active={isRecording} label={isRecording ? 'Listening' : 'Idle'} />
          <div className="flex items-center gap-2 bg-zinc-100 dark:bg-zinc-800 rounded-lg px-2 py-1">
             <select 
              className="bg-transparent border-none text-xs focus:ring-0 outline-none"
              value={selectedDeviceId}
              onChange={(e) => setSelectedDeviceId(e.target.value)}
            >
              {audioDevices.map(device => (
                <option key={device.deviceId} value={device.deviceId}>
                  {device.label || `Microphone ${device.deviceId.slice(0, 5)}`}
                </option>
              ))}
            </select>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Chat History */}
        <aside className="w-64 border-r border-zinc-200 dark:border-zinc-800 bg-zinc-100/30 dark:bg-zinc-900/30 flex flex-col overflow-hidden hidden lg:flex">
          <div className="p-4">
            <button 
              onClick={createNewChat}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-blue-500/20"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Новый чат
            </button>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
            <h3 className="px-3 py-2 text-[10px] font-bold uppercase tracking-widest opacity-40">История чатов</h3>
            {sessions.map(s => (
              <button
                key={s.id}
                onClick={() => setActiveSessionId(s.id)}
                className={`w-full flex flex-col px-4 py-3 rounded-xl text-left transition-all ${
                  activeSessionId === s.id 
                    ? 'bg-zinc-200 dark:bg-zinc-800 shadow-sm' 
                    : 'hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 opacity-60'
                }`}
              >
                <span className="text-sm font-medium truncate w-full">{s.title}</span>
                <span className="text-[10px] opacity-40">{new Date(s.createdAt).toLocaleDateString()}</span>
              </button>
            ))}
          </div>
          <div className="p-4 border-t border-zinc-200 dark:border-zinc-800">
             <button 
                onClick={clearCurrentChat}
                className="w-full flex items-center justify-center gap-2 py-2 text-red-500 hover:bg-red-500/10 rounded-lg text-xs font-medium transition-all"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                Очистить этот чат
              </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex overflow-hidden relative">
          {operationStatus && (
              <div className="absolute inset-x-0 top-0 z-40 p-4 animate-in slide-in-from-top-4 duration-300">
                  <div className="bg-blue-600 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-4 max-w-md mx-auto ring-4 ring-white/10">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <div className="flex-1">
                          <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Системный интеллект</p>
                          <p className="text-sm font-medium truncate">{operationStatus}</p>
                      </div>
                  </div>
              </div>
          )}

          {/* Chat Area */}
          <section className="flex-1 flex flex-col overflow-hidden relative">
            <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4 pb-32">
              {messages.length === 0 && (
                <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                  <div className="w-20 h-20 bg-zinc-200 dark:bg-zinc-800 rounded-full flex items-center justify-center mb-6">
                    <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                  </div>
                  <h2 className="text-xl font-medium max-w-sm">Выберите голос и после этого говорите команды</h2>
                </div>
              )}
              
              {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                  <div className={`max-w-[85%] px-4 py-3 rounded-2xl shadow-sm transition-all duration-300 ${
                    msg.sender === 'user' 
                      ? 'bg-blue-600 text-white rounded-tr-none' 
                      : 'bg-zinc-200 dark:bg-zinc-800 rounded-tl-none border border-zinc-300/20 dark:border-zinc-700/50'
                  }`}>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                    <p className="text-[10px] mt-1 opacity-50 text-right">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Floating Microphone */}
            <footer className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50">
              <button
                onClick={startSession}
                className={`group relative flex items-center justify-center w-20 h-20 rounded-full transition-all duration-300 shadow-[0_20px_50px_rgba(0,0,0,0.3)] ${
                  isRecording 
                    ? 'bg-red-500 hover:bg-red-600 scale-110 active:scale-95' 
                    : 'bg-blue-600 hover:bg-blue-700 hover:scale-105 active:scale-95'
                }`}
              >
                {isRecording ? (
                  <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" />
                  </svg>
                ) : (
                  <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                )}
                {isRecording && <div className="absolute inset-0 rounded-full animate-ping bg-red-500/40 opacity-75 pointer-events-none" />}
              </button>
            </footer>
          </section>

          {/* Right Sidebar */}
          <aside className="w-80 border-l border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50 p-6 flex flex-col gap-8 hidden xl:flex">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider opacity-50 mb-4">Голос Ассистента</h3>
              <div className="flex p-1 bg-zinc-200 dark:bg-zinc-800 rounded-xl mb-4">
                <button 
                  onClick={() => { setVoiceGender('male'); setSelectedVoiceId(VOICE_OPTIONS.male[0].id); }}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${voiceGender === 'male' ? 'bg-white dark:bg-zinc-700 shadow-sm' : 'opacity-50'}`}
                >
                  Мужской
                </button>
                <button 
                  onClick={() => { setVoiceGender('female'); setSelectedVoiceId(VOICE_OPTIONS.female[0].id); }}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-all ${voiceGender === 'female' ? 'bg-white dark:bg-zinc-700 shadow-sm' : 'opacity-50'}`}
                >
                  Женский
                </button>
              </div>
              <div className="space-y-2">
                {VOICE_OPTIONS[voiceGender].map(voice => (
                  <button
                    key={voice.id}
                    onClick={() => setSelectedVoiceId(voice.id)}
                    className={`w-full flex flex-col p-3 rounded-xl border text-left transition-all ${
                      selectedVoiceId === voice.id 
                        ? 'bg-blue-600/10 border-blue-500 shadow-sm ring-1 ring-blue-500' 
                        : 'bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 hover:border-zinc-300 dark:hover:border-zinc-600'
                    }`}
                  >
                    <span className="text-sm font-semibold">{voice.name}</span>
                    <span className="text-[10px] opacity-60 leading-tight">{voice.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-hidden flex flex-col">
              <h3 className="text-xs font-bold uppercase tracking-wider opacity-50 mb-4">Лог автоматизации</h3>
              <div className="space-y-3 overflow-y-auto custom-scrollbar pr-2">
                {commands.map(cmd => (
                  <div key={cmd.id} className="p-3 bg-white dark:bg-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-700 shadow-sm group hover:border-blue-500 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-sm truncate">{cmd.name}</span>
                      <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-md ${cmd.type === 'system' ? 'bg-zinc-100 dark:bg-zinc-700' : 'bg-green-500 text-white'}`}>
                        {cmd.type === 'system' ? 'SYS' : 'AUTO'}
                      </span>
                    </div>
                    <p className="text-xs opacity-60 leading-tight mb-2">{cmd.description}</p>
                    {cmd.code && (
                      <div className="p-1.5 bg-zinc-950 rounded font-mono text-[9px] text-green-400 overflow-x-auto whitespace-nowrap custom-scrollbar">
                        {cmd.code}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </main>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(128, 128, 128, 0.2); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(128, 128, 128, 0.4); }
      `}</style>
    </div>
  );
};

export default App;
