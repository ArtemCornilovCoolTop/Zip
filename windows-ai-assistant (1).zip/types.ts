
export enum AppTheme {
  LIGHT = 'light',
  DARK = 'dark'
}

export interface Command {
  id: string;
  name: string;
  description: string;
  type: 'system' | 'custom';
  code?: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}
